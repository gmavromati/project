$(function(){
	$("#wizard").steps({
        headerTag: "h4",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        transitionEffectSpeed: 500,
        labels: {
            next: "Next",
            previous: "Back"
        },
        onStepChanging: function (event, currentIndex, newIndex) { 
            if ( newIndex === 1 ) {
                $('.steps ul').addClass('step-2');
                $('.actions ul li:nth-child(2)').addClass('step-2');
                $('.actions ul li:nth-child(2) a').html('Next');
            } else if ( newIndex === 2 ) {
                $('.steps ul').addClass('step-3');
                $('.actions ul li:nth-child(3)').addClass('step-3');
                $('.actions ul li:nth-child(3) a').html('Next');
            } if ( newIndex === 3 ) {
                $('.steps ul').addClass('step-4');
                $('.actions ul li:nth-child(4)').addClass('step-4');
                $('.actions ul li:nth-child(4) a').html('Next');
            } else if ( newIndex === 4 ) {
                $('.steps ul').addClass('step-5');
                $('.actions ul li:nth-child(5)').addClass('step-5');
                $('.actions ul li:nth-child(5) a').html('Next');
            } else if ( newIndex === 5 ) {
                $('.steps ul').addClass('step-6');
                $('.actions ul li').addClass('step-last');
                $('.actions ul li').hide();
            } else {
                $('.steps ul').removeClass('step-6');
            }
            return true; 
        }
    });

    // Custome Jquery Step Button
    $('.forward').click(function(){
    	$("#wizard").steps('next');
    })
    $('.backward').click(function(){
        $("#wizard").steps('previous');
    })
})
